<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Fusepong Full Stack V2</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body>
        <div class="cover">
            <div id="app">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-5 mt-5">

                            <img src="<?php echo e(asset('img/logo.png')); ?>" class="logo" >

                            <div class="card">
                                <div class="card-body px-4">
                                    <h3 class="mb-5 text-center">Ingresar</h3>

                                    <?php echo $__env->make('auth/login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </body>
</html>
<?php /**PATH C:\workspace\fusepong\resources\views/welcome.blade.php ENDPATH**/ ?>