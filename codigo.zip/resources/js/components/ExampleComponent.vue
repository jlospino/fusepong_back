<template lang="html">

</template>

<script>
    import image from '../../../public/img/logo.png'
    export default {
        mounted() {
            console.log('Component mounted.')
        },
        data: function () {
        return {
            image: image
        }
    }
    }
</script>

<style>

</style>
