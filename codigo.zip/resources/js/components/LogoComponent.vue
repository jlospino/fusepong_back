<template>
    <h3>Fusepong Full Stack V2</h3>
</template>

<script>
    export default {
        mounted() {
            // console.log('Component mounted.')
        }
    }
</script>
